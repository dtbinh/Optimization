function [output1,output2] = distance_from_target(target_loc,particle_loc)

for i = 1:size(target_loc,1)
    dist_mat = pdist2(target_loc(i,1:2),particle_loc(:,1:2));
    close_dist_ind = find(dist_mat<0.15);
    if length(close_dist_ind)>4
        target_loc(i,3) = 1;
        particle_loc(close_dist_ind,3) = 0;
        particle_loc(close_dist_ind,4:7) = 0;
    end
end

output1 = particle_loc;
output2 = target_loc;