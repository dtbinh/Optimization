function output = Intensity_tracking(x,target_loc)

%Depending the number of targets the intensity of each target should....
%..be included in the function

%Weights are assigned to each intensity function which decide which.....
%... target to be tracked by a set of bots from the swarm.

%Considering all the targets have equal transmission distance of 1m 
%-- location of targets
% target_loc1 = target_loc(1,1:2);
% target_loc2 = target_loc(2,1:2);
% target_loc3 = target_loc(3,1:2);
% N_targets = 3;
%-- Weights are either 1 or 0 depending upon the location to search
% w = ones(1,N_targets);

% target_location = [target_loc1;target_loc2;target_loc3];
% dist_vec = pdist2(x,target_location);
%-- Finding the targets which are far away from the particle location and..
%.. assigning the weigths equal to zero
% range_of_target = 2;
% [~,ind_w] = find(dist_vec(1,:) > range_of_target);
% w(1,ind_w)= 0;

f = zeros(size(target_loc,1),1);
%-- Intensity 
sigma_dis = 1;
for i = 1:size(target_loc,1)
    if target_loc(i,3) == 0
        f(i,1) = gaussian_distribution(x,target_loc(i,1:2),sigma_dis);
    else
        f(i,1) = 0; 
    end
    if f(i,1) < 0.1
       f(i,1) = 0;
    end
end
output = sum(f);
