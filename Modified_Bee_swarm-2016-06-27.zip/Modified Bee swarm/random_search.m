function output = random_search(alpha,angle)

% alpha is the scalar parameter
x_dir = alpha*cos(angle);
y_dir = alpha*sin(angle);

output = [x_dir y_dir];