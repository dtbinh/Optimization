%% -- Modified Algorithm for Random search and Bee swarm implementation.

% 'Multi target tracking using swarm of quadcopters'
% written by Sri Sadhan Jujjavarapu on 25th April 2016

% Nomenclature
% target_loci are the locations of the target
% the objective functive used here is given in the file gaussian_distribution
% Intensity_tracking calls back the target distribution function
% Two types of random searches are used: 1)Levy search 2) Random search
% Levy function was written by Hemanth Manjunatha.

function_des = @Intensity_tracking; % function file
%-- target location
target_loc1 = [3,3];
target_loc2 = [9,9];
target_loc3 = [1,8];
target_loc4 = [6,2];
target_location = zeros(4,3); % changes have to be made depending upon the number of target locations
% third column represents 0 or 1
% 0 - target not found
% 1 - target found

target_location(:,1:2) = [target_loc1;target_loc2;target_loc3;target_loc4];% if a new target is added, drop it into the list

%-- boundary conditions of search space
x1_l = 0;% lower bound in x1 direction
x1_u = 10;% upper bound in x1 direction
x2_l = 0;%lower bound in x1 direction
x2_u = 10;% upper bound in x1 direction

n = 2;% 'n' is the number of variables- 2d search space
N = 50;% 'N' is the number of particles
n_scouts = N*0.2;% 20% of the population are maintained as scouts all the time
alpha = 0.5;% inertial coefficient 0<='alpha'<=1
beta_l = 0.1;% local search coefficient 1<='beta_l'<=2
beta_g = 0.1;% Global search coefficient 1<='beta_g'<=2
N_targets = size(target_location,1);% Number of targets in the search space
runs = 0;
range_of_target = 1;

pop = zeros(N,n+5);
vel_vec = zeros(N,2); 

fit_gbest = zeros(N,1); % global best fitness
n_targets = 0;
n_feval = 0;
min_vec = [];
fit_pbest = zeros(N,1);
p_best = zeros(N,2);
% dist_exp = 1000*ones(N,3);% distance of each particle from target

%--Video
writerobj = VideoWriter('Bee_Swarm.avi');
writerobj.FrameRate = 5;
open(writerobj);

figure()
while n_targets < N_targets
    
    % function evaluation
    f = zeros(N,1);
    for i = 1:N
        f(i,1) = function_des(pop(i,1:2),target_location);
    end
    fit_eval = f;
    [~,ind_f] = find(f==0);
    
    if length(ind_f) == N
        %-- Initial Random search
        % Considering a square section, the search starts at a corner
        % 90 degrees angle is divided into N divisions
        % particles move in the respective areas
        angle_rand = 0;
        for j = 1:N
            alpha_rand = rand;
            angle_rand = angle_rand + pi/(2*N);
            vel_vec(j,:) = random_search(alpha_rand,angle_rand);
            pop(j,1:2) = pop(j,1:2) + vel_vec(j,:);
            
            if pop(j,1) > x1_u
                pop(j,1) = x1_u;
            elseif pop(j,1) < x1_l
                pop(j,1) = x1_l;
            end
            if pop(j,2) > x2_u
                pop(j,2) = x2_u;
            elseif pop(j,2) < x2_l
                pop(j,2) = x2_l;
            end
        end
    else
%-- Modified PSO algorithm
        %-- Local best evaluation
        for k = 1:N
            if fit_eval(k,1)>0
                pop(k,3) = 2; % 2 is the flag for experienced particles
            end
            if fit_eval(k,1)>fit_pbest(k,1)
                fit_pbest(k,1) = fit_eval(k,1);
                pop(k,4:5) = pop(k,1:2);
            end
        end
        %--
        temp_exp = find(pop(:,3)==2);
        dist_exp = pdist2(pop(temp_exp,1:2),pop(temp_exp,1:2));
        [l,m] = find(dist_exp>0.5*range_of_target & dist_exp~=0);
        %-- Global best evaluation
        for l1 = 1:length(l)
            for m1 = 1:length(m)
                if fit_eval(temp_exp(l(l1),1))>fit_eval(temp_exp(m(m1),1))
                    if dist_exp(l(l1),m(m1)) < 2
                        pop(temp_exp(m(m1),1),3) = 1;% 1 is the flag for onlookers
                        pop(temp_exp(m(m1),1),6:7) = pop(temp_exp(l(l1),1),4:5);
                    else
                        pop(temp_exp(m(m1),1),3) = 0;% 0 is the flag for scouts
                    end
                else
                    pop(temp_exp(m(m1),1),3) = 2;
                    pop(temp_exp(l(l1),1),6:7) = pop(temp_exp(m(m1),1),4:5);
                end
            end
        end
        angle_rand = 0;
        for j = 1:N
            alpha_rand2 = 3*rand;
            angle_rand2 = (rand-0.5)*2*pi;
            r1 = rand;
            r2 = rand;
            if pop(j,3) == 2
                vel_vec(j,:) = alpha*vel_vec(j,:)+ r1*beta_l*(pop(j,4:5)-pop(j,1:2)) + r2*beta_g*(pop(j,6:7)-pop(j,1:2));
            elseif pop(j,3) == 0
                vel_vec(j,:) = levy(1,2,1.15);%random_search(alpha_rand2,angle_rand2);% random search
            else
                vel_vec(j,:) = alpha*vel_vec(j,:) + r2*beta_g*(pop(j,6:7)-pop(j,1:2));
            end
            
            pop(j,1:2) = pop(j,1:2) + vel_vec(j,:); % new position of the particle
            %-- Keep the position update of particle in the feasible region. 
            if pop(j,1) > x1_u
                pop(j,1) = 2*x1_u-pop(j,1);
            elseif pop(j,1) < x1_l
                pop(j,1) = 2*x1_l-pop(j,1);
            end
            if pop(j,2) > x2_u
                pop(j,2) = 2*x2_u-pop(j,2);
            elseif pop(j,2) < x2_l
                pop(j,2) = 2*x2_l-pop(j,2);
            end
        end
    end

    h = plot(pop(:,1),pop(:,2),'b.');
    xlim([0 10]);
    ylim([0 10]);
    hold on
    [pop,target_location] = distance_from_target(target_location,pop);
    found_loc = find(target_location(:,3)==1);
    if length(found_loc)>0
        n_targets = length(found_loc);  
        plot(target_location(found_loc,1),target_location(found_loc,2),'r*','linewidth',2);
        xlim([0 10]);
        ylim([0 10]);
    end
    mTextBox = uicontrol('style','text','Position', [390 360 100 25]);
    set(mTextBox,'String',strcat('Number of targets found:',num2str(n_targets)),'BackgroundColor',[1 1 1]);

    current_frame = getframe(gcf);
    writeVideo(writerobj, current_frame);
    pause(0.0001)
    if n_targets ~= N_targets
        delete(h)
    else
        pause(5)
    end
    
end
writeVideo(writerobj, current_frame);
close(writerobj);
