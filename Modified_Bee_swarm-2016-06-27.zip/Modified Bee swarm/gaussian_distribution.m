function output = gaussian_distribution(x,mean,sigma)

output = exp(-((x(1)-mean(1)).^2 + (x(2)-mean(2)).^2)/(2*sigma.^2))/(sqrt(2*pi)*sigma);